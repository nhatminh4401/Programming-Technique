#include<iostream>
#include<cmath>
#include<fstream>
using namespace std;

struct Location
{
	double x,y;		
};

#define TYPE_TEA  0
#define TYPE_COFFEE  1

struct Tree
{
	Location pos;
	int type;
};

#define MAX_TREE  100
struct Plantation
{
	Tree trees[MAX_TREE];
	int treeCount;
};

int countTrees(Plantation p, int type);
int countCoffeeTrees(Plantation p);
int countTeaTrees(Plantation p);
float calcFenceLength(Plantation p);
float calculateTotalLength(Plantation p);
Location findPump(Plantation p);
float distance(Location p, Location q);

int main()
{
	Plantation p;
	ifstream f1;
	
	f1.open("D:/NongTrai.in.txt"); // <----- Link for input text file
	if(!f1.is_open())
	{
		cout << "Cannot open file.\n";
	}
	else
	{	
		f1 >> p.treeCount;
		for(int i = 0; i < p.treeCount; i++)
		{
			f1 >> p.trees[i].pos.x;
			f1 >> p.trees[i].pos.y;
			f1 >> p.trees[i].type;
		}
		ofstream f2;
		f2.open("D:/NongTrai.out.txt");
		if(!f2.is_open())
		{
			cout <<"Cannot create file. \n";
		}
		else
		{
			f2 << countCoffeeTrees(p) << " " << countTeaTrees(p) << endl;
			f2 << calcFenceLength(p) << endl;
			f2 << calculateTotalLength(p);
			f2.close();
		}
		
		f1.close();
	}
}

// Count trees of a specific type. 
int countTrees(Plantation p, int type)
{
	int count = 0;
	for(int i = 0; i < p.treeCount; i++)
		if(p.trees[i].type == type )
			count++;
	return count;
}

// Count coffee trees. 
int countCoffeeTrees(Plantation p)
{
	return countTrees(p, TYPE_COFFEE);
}

// Count tea trees. 
int countTeaTrees(Plantation p)
{
	return countTrees(p, TYPE_TEA);
}

// Find upper left point. 
Location findUpperLeft(Plantation p) 
{
	double xmin = p.trees[0].pos.x;
	double ymax = p.trees[0].pos.y;
	
	for(int i = 0; i < p.treeCount; i++)
	{
		if(p.trees[i].pos.x < xmin)
			xmin = p.trees[i].pos.x;
		if(p.trees[i].pos.y > ymax)
			ymax = p.trees[i].pos.y;
	}
	
	Location upper;
	upper.x = xmin;
	upper.y = ymax;
	
	return upper;
}

// Find lower right point.
Location findLowerRight(Plantation p) 
{
	double xmax = p.trees[0].pos.x;
	double ymin = p.trees[0].pos.y;
	
	for(int i = 0; i < p.treeCount; i++)
	{
		if(p.trees[i].pos.x > xmax)
			xmax = p.trees[i].pos.x;
		if(p.trees[i].pos.y < ymin)
			ymin = p.trees[i].pos.y;
	}
	
	Location lower;
	lower.x = xmax;
	lower.y = ymin;
	
	return lower;
}

// Calculate perimeter of rectangular fence.
float calcFenceLength(Plantation p)
{
	Location upper = findUpperLeft(p);
	Location lower = findLowerRight(p);
	
	double dx = abs(upper.x - lower.x);
	double dy = abs(upper.y - lower.y);
	
	return (dx + dy)*2;
}

// Calculate total length of tubes.
float calculateTotalLength(Plantation p)
{
	double s = 0;
	Location pump = findPump(p);
	
	for(int i = 0; i < p.treeCount; i++)
	{
		s += ::distance(pump, p.trees[i].pos);
	}
	return s;
}

// Find position of the pump.
// It�s the center of all trees!!!
Location findPump(Plantation p)
{
	Location pump;
	double s1,s2 = 0;
	int count = 0;
	for(int i = 0; i < p.treeCount; i++ )
	{
		s1 += p.trees[i].pos.x;
		s2 += p.trees[i].pos.y;
		count++;
	}
	pump.x = s1/count;
	pump.y = s2/count;
	return pump;
}
// Calculate distance between two point.
float distance(Location p, Location q)
{
	return sqrt(pow(q.x - p.x,2) + pow(q.y - p.y,2));
} 
