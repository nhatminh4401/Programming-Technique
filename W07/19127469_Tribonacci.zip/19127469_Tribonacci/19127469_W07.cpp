unsigned int memory[38];  // [38] because n <= 37 so we don't need larger number
class Solution {
public:
    unsigned int tribonacci(int n) {  //unsigned because tribonacci always >= 0
        if(memory[n] > 0)         //we use memory to save the result, so we don't need to calculate again.
            return memory[n];
        if(n == 0)
            return memory[n] = 0;
        if(n < 3)
            return memory[n] = 1;
        else
            return memory[n] = (tribonacci(n - 1) + tribonacci(n - 2) + tribonacci(n - 3) );
    }
};
