#include "Function.h"

Node *createNode(int x)
{
	Node *p = new Node;
	p->data = x;
	p->next = NULL;
	return p;
}

void inputNodes(LinkedList &lst)
{
	lst.head = NULL;

	int x;
	int i = 0;
	Node *temp;
	cout << "****Enter a not number character to stop inputting!!!****\n";
	while(true) 
	{
		cout << "Enter Node[" << i++ << "]: " << endl;
        if(!(cin >> x)) 
            break;
        else 
		{
            temp = createNode(x);
            temp->next = lst.head;
            lst.head = temp;
        }
        
    }
    
}

void printNodes(LinkedList lst)
{
	Node *cur = lst.head;
	while(cur != NULL)
	{
		cout << cur->data << " ";
		cur = cur->next;
	}
}

int countNodes(LinkedList lst)
{
	int count = 0;
	for(Node* temp = lst.head; temp != NULL; temp = temp->next)
	{
		count++;
	}
	return count;
}

void reverseList(LinkedList &lst)
{
	Node *cur1 = NULL;
 	Node *cur2 = lst.head; 
    Node *cur3 = lst.head->next; 
  
    while (cur2 != NULL) 
	{ 
        cur3 = cur2->next; 
  
    	cur2->next = cur1; 
  
        cur1 = cur2; 
        cur2 = cur3; 
    } 
    lst.head = cur1; 
}

void addNode(LinkedList &lst, int x)
{
	Node* cur;
	Node *p = createNode(x);
	if(lst.head == NULL || lst.head->data >= p->data) // case for head.
	{
		p->next = lst.head;
		lst.head = p;
	}
	else  // case for middle and end.
	{
		cur = lst.head;
		while(cur->next != NULL && cur->next->data < p->data)
		{
			cur = cur->next;
		}
		
		p->next = cur->next;
		cur->next = p;
	}
}
