//main.cpp
#include "Function.h"

int main(){
	int x;
	cout << "Enter value of new node: ";
	cin >> x;
	LinkedList lst;

	inputNodes(lst);
	reverseList(lst);
	printNodes(lst);
	cout << "\nNumber of nodes: " << countNodes(lst);
	
	cout << endl;
	cout << "New node added: ";
	addNode(lst, x);
	printNodes(lst);
	
	cout << endl;
	cout << "Reversed list: ";
	reverseList(lst);
	printNodes(lst);
	return 0;
}
