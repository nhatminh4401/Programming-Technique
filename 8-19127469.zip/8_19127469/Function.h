#ifndef FUNCTION_H
#define FUNCTION_H

#include<iostream>
using namespace std;

struct Node
{
	int data;
	Node *next;	
};

struct LinkedList
{
	Node *head;
};
Node *createNode(int x);
void inputNodes(LinkedList &lst);
void printNodes(LinkedList lst);
int countNodes(LinkedList lst);
void reverseList(LinkedList &lst);
void addNode(LinkedList &lst, int x);
#endif
