#include "Function.h"

void copyFile_1(char *file1, char *file2)
{
	FILE *f1 = fopen(file1, "rb");
	FILE *f2 = fopen(file2, "wb");
	
	if (f1 == NULL || f2 == NULL)
		return;
	char buf[MAX_BUF];
	int count;
	
	do
	{
		count = fread(buf, 1, MAX_BUF, f1);
		fwrite(buf, 1, count, f2);
	}
	while (count == MAX_BUF);
	
	fclose(f1);
	fclose(f2);
}

void copyFile_2(char *file1, char *link)
{
	FILE *f1 = fopen(file1, "rb");
	int l = strlen(file1); //length of file1
	int count = 0;
	char a[MAX]; // a static array to save the link.
	strcpy(a, link);

	do
	{
		count++; // count the element of the array where the file's name appears
	}
	while(file1[l - 1 - count] != '/');
	
	char b[MAX]; //a static array to save the file's name
	int k = 0;
	for(int i = l - count; i <= l; i++) //we must use i <= l to take '\0' from file1 into b, to make sure that b has '\0'
	{
		b[k++] = file1[i]; 
	}

	strcat(a, b);
	link = a;

	FILE *f2 = fopen(link, "wb");
	
	if (f1 == NULL || f2 == NULL)
		return;
	char buf[MAX_BUF];
	
	do
	{
		count = fread(buf, 1, MAX_BUF, f1);
		fwrite(buf, 1, count, f2);
	}
	while (count == MAX_BUF);
	
	
	fclose(f1);
	fclose(f2);
}

void copyFile_3(char *file1, char *file2, char *file3)
{
	FILE *f1 = fopen(file1, "rb");
	FILE *f2 = fopen(file2, "rb");
	FILE *f3 = fopen(file3, "wb");
	
	if (f1 == NULL || f2 == NULL || f3 == NULL)
		return;
	char buf[MAX_BUF];
	int count;
	
	do
	{
		count = fread(buf, 1, MAX_BUF, f1);
		fwrite(buf, 1, count, f3);
	}
	while (count == MAX_BUF);
	
	do
	{
		count = fread(buf, 1, MAX_BUF, f2);
		fwrite(buf, 1, count, f3);
	}
	while (count == MAX_BUF);
	
	fclose(f1);
	fclose(f2);
	fclose(f3);
}

void showHelp()
{
	cout << "\n=============COPY COMMAND-LINE SYNTAX=============\n";
	cout << "To copy a file to another file" << endl;
	cout << "--> COPY <source file> <destination file>" << endl;
	cout << "To copy a file to another destination" << endl;
	cout << "--> COPY <source file> <destination path> "<< endl;
	cout << "To merge/append 2 files" << endl;
	cout << "--> COPY <file 1> + <file 2> <destination file>" << endl;
	cout << "To show help" <<endl;
	cout << "--> COPY /?" << endl;
}
