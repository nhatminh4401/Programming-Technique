#include "Function.h"

int main(int argc, char **argv)
{
	int **a;
	if (argc == 1)
		cout << "Error: no input argument.";
	else
	{
		if(strcmp(argv[1], "/?" ) == 0 )
			showHelp();
		else if (argc == 3)
		{
			if(strstr(argv[2], ".") != NULL ) //if the argument variable 2 doesn't have "." means .txt or .bin, etc.
			{
				copyFile_1(argv[1], argv[2]);
				cout << "Copy successfully. ";
			}
			else
			{
				copyFile_2(argv[1], argv[2]);
				cout << "Copy successfully. ";
			}
			
		}
		else if(argc == 4)
		{
			copyFile_3(argv[1], argv[2], argv[3]);
			cout << "Copy successfully. ";
		}
	}
}
