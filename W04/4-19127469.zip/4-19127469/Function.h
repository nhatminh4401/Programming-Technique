#ifndef FUNCTION_H
#define FUNCTION_H

#include<iostream>
#include<fstream>
#include<cstring>
#define MAX_BUF 100
#define MAX 101
using namespace std;

void copyFile_1(char *file1, char *file2);
void copyFile_2(char *file1, char *link);
void copyFile_3(char *file1, char *file2, char *file3);
void showHelp();

#endif
