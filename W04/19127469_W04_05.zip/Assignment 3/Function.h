#ifndef FUNCTION_H
#define FUNCTION_H

#include<iostream>
#include<fstream>
#include<cstring>
#define MAX_BUF 100
#define MAX 101
using namespace std;


void copyFile(char *file1, char *link);



#endif
