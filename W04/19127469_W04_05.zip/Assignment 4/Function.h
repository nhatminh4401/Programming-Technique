#ifndef FUNCTION_H
#define FUNCTION_H

#include<iostream>
#include<fstream>
#include<cstring>
#include <stdlib.h>
#define MAX_BUF 100
#define MAX 101
using namespace std;

void splitFile_1(char *file1, char *file2, int numpart);
void splitFile_2(char *file1, char *file2, int sizeapart);

#endif
