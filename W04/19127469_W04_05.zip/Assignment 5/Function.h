#ifndef FUNCTION_H
#define FUNCTION_H

#include<iostream>
#include<fstream>
#include<cstring>
#include <stdlib.h>
#define MAX 101
#define MAX_BUF 100
using namespace std;

int mergeFile(char *file1, char *file2);

#endif
