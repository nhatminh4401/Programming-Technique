#include "Function.h"


bool isBmpFile(FILE* f)
{
	if (f == NULL)
		return false;
		
		BmpSignature signature;
		fseek(f, 0, SEEK_SET);
		fread(&signature, sizeof(BmpSignature), 1, f);
		
		return signature.data[0] == 'B' && signature.data[1] == 'M';
}

void readBmpHeader(FILE* f, BmpFile& bmp)
{
	if (f == NULL)
		return;
	
	fseek(f, 0, SEEK_SET);
	fread(&bmp.header, sizeof(BmpHeader), 1, f);
}

void readBmpDib(FILE* f, BmpFile& bmp)
{
	if (f == NULL)
		return;
	
	fseek(f, sizeof(BmpHeader), SEEK_SET);
	fread(&bmp.dib, sizeof(BmpDib), 1, f);
}

void readBmpPixelArray(FILE* f, BmpFile &bmp)
{
	if (f == NULL)
		return;
	
	int widthSize = bmp.dib.imageWidth * (bmp.dib.pixelSize / 8);
	bmp.pixelArray.paddingSize = (4 - (widthSize % 4)) % 4;
	bmp.pixelArray.lineSize = widthSize + bmp.pixelArray.paddingSize;
	bmp.pixelArray.rawByteSize = bmp.pixelArray.lineSize * bmp.dib.imageHeight;
	bmp.pixelArray.rawBytes = new unsigned char[bmp.pixelArray.rawByteSize];
	
	fseek(f, bmp.header.dataOffset, SEEK_SET);
	fread(bmp.pixelArray.rawBytes, bmp.pixelArray.rawByteSize, 1, f);
	
	initPixels(bmp.pixelArray, bmp.dib.imageWidth, bmp.dib.imageHeight);
}

void initPixels(PixelArray& pa, int width, int height)
{
	pa.rowCount = height;
	pa.columnCount = width;
	
	pa.pixels = new Color *[pa.rowCount];
	for(int i = 0; i < pa.rowCount; i++)
		pa.pixels[pa.rowCount -1 -i] = (Color *) (pa.rawBytes + pa.lineSize * i);
}

void drawBmp(const BmpFile& bmp)
{
	HWND console = GetConsoleWindow();
	HDC hdc = GetDC(console);
	
	for(int i = 0; i < bmp.dib.imageHeight; i++)
		for(int j = 0; j < bmp.dib.imageWidth; j++)
		{
			Color pixel = bmp.pixelArray.pixels[i][j];
			SetPixel(hdc, j, i, RGB(pixel.red, pixel.green, pixel.blue));
		}
		
	ReleaseDC(console, hdc);
}
void releaseBmpPixelArray(BmpFile& bmp)
{
	delete[]bmp.pixelArray.pixels;
	delete[]bmp.pixelArray.rawBytes;
}

void readBmpFile(const char* filename, BmpFile& bmp)
{
	FILE *f = fopen(filename, "rb");
	
	if(f == NULL || !isBmpFile(f))
	{
		printf("Error or invalid Bmp File.\n");
		return;
	}
	
	readBmpHeader(f, bmp);
	readBmpDib(f, bmp);
	readBmpPixelArray(f, bmp);
	
	fclose(f);
}

void printRGB_info(const char* filename, BmpFile& bmp)
{
	FILE *f = fopen(filename, "rb");
	if (f == NULL)
		return;
	int i, j;
	Color a;
	cout << " *** Note: top-left of the image has i = 0, j = 0. *** " << endl;
	cout << "Enter i, j:";
	cin >> i >> j;
	int pos = 54 + bmp.pixelArray.lineSize * (bmp.dib.imageHeight - 1 - i) + j * bmp.dib.pixelSize / 8;
	fseek(f, pos, SEEK_SET);
	fread(&a, sizeof(Color), 1, f);
	cout << "Red: " << (int)a.red;
	cout << "\nGreen: " <<(int)a.green;
	cout << "\nBlue: " << (int)a.blue;
}
