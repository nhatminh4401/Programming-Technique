#include "Function.h"
#define BMP_SOURCE "lena.bmp"

void readBmp()
{
	BmpFile bmpSource;
	
	readBmpFile(BMP_SOURCE, bmpSource);

	printRGB_info(BMP_SOURCE, bmpSource);
	cout << endl;
	getchar();
	system("pause");
	system("cls");
	drawBmp(bmpSource);

	releaseBmpPixelArray(bmpSource);
}
int main(){
	readBmp();
	return 0;
}
