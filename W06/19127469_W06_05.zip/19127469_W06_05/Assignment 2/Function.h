#ifndef FUNCTION_H
#define FUNCTION_H

#include<iostream>
#include<cstring>
#define MAX 100
using namespace std;

bool isPalindrome(int l, int r, char* s);


#endif
