#include "Function.h"

int main()
{

	int n;  
	cout << "Enter number of disks: ";
	cin >> n;
	cout << endl;
    hn_tower(n, 'A', 'C', 'B'); // A, B and C are names of rods  
    return 0;  
}

