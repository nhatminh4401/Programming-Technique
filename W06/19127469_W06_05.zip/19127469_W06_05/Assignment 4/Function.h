#ifndef _FUNCTION_H_
#define _FUNCTION_H_

#include <iostream>
#define source A
#define dest C
#define temp B
using namespace std;


void hn_tower(int n, char source, char dest, char temp);

#endif
