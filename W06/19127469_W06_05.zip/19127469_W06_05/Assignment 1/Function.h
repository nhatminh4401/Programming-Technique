#ifndef FUNCTION_H
#define FUNCTION_H

#include<iostream>
#include<cmath>

using namespace std;

int fibo(int n);
int xn_yn_1(int n);
int xn_yn_2(int n);
int xn(int n);
int c_nk(int n, int k);
void toBinary(int x);
int sumOfDigits(int x);

#endif
