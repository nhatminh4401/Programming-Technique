#ifndef FUNCTION_H
#define FUNCTION_H

#include<iostream>
using namespace std;

int sum_even(int *a, int n, int sum);
void findPos_x(int *a, int n, int x);
bool isPrime(int n, int i = 2);
void findPrime(int *a, int n);


#endif
