#include "Function.h"

int main(){
	int n;
	int x;
	int sum = 0;
	
	cout << "Enter n: ";
	cin >> n;
	int a[n];
	for(int i = 0; i < n; i++)
	{
		cout << "\nEnter a[" << i << "] = ";
		cin >> a[i];
	}
	
	cout << "\nSum all even numbers: " << sum_even(a, n - 1, sum);  // a)
	
	cout << "\n\nEnter x: ";   // c)
	cin >> x;
	cout << "\nPosition of " << x << " is ";
	findPos_x(a, n, x);
	
	cout << "\n\nPrime numbers: ";   // d)
	findPrime(a, n - 1);
	
	return 0;
}
