#include "Function.h"

int sum_even(int *a, int n, int sum){

	if(n < 0)
		return sum;
	if(a[n] % 2 == 0)
		sum += a[n];
		
	sum_even(a, n - 1, sum);
}

void findPos_x(int *a, int n, int x){
	if(n < 0)	
		return;
		
	if(a[n] == x)
		cout << "[" << n << "], ";
		
	findPos_x(a, n - 1, x);
}

int findElement(int *a, int l, int r, intx){
	// Base case, small array
	if(l == r)
		return (a[l] == x) ? l : -1;
	// Recursive case, array is big!
	int mid = (l + r) / 2;
	//left part: l --> mid
	int pos = findElement(a, l, mid, x);
	return (pos != -1) ? pos : return findElement(a, mid + 1, r, x);
	//right part: mid + 1 --> r
	
}

bool isPrime(int n, int i){ 
    if(n <= 2) 
        return (n == 2) ? true : false; // Prime number starts from 2 not 1 or even lower!!
        
    if(n == i) 
        return true;
	else
	{
		if(n % i == 0)  
        	return false;
        else
        	isPrime(n, i + 1);
	}
    return isPrime(n, i + 1); 
}

void findPrime(int *a, int n){
	if(n < 0)
		return;
	
	if(isPrime(a[n]) == 1)
		cout << a[n] << ", ";
		
	findPrime(a, n - 1);
}
