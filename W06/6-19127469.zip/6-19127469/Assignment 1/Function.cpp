#include "Function.h"

int s_n_1(int n){ // a)S(n)
	if(n <= 0)
		return 0;
	return s_n_1(n - 1) + n;
}

int t_n(int n, int x){   // b)T(n)
	if(n == 0)
		return 1;
	return t_n(n - 1, x) * x;
}

float s_n_2(int n){  // c)S(n)
	if(n == 1)
		return 1;
	if(n % 2 == 0)
		return (float) - 1/n + s_n_2(n - 1);
	else
		return (float) 1/n + s_n_2(n - 1);
}
