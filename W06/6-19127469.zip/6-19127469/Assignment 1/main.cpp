#include "Function.h"

int main(){
	int n, x;
	cout << "Enter n: "; //a)
	cin >> n;
	cout << "\na) S(n) ";
	cout << "\nS(" << n << ") = " << s_n_1(n);
	
	cout << "\n\nEnter n: ";  //b)
	cin >> n;
	cout << "Enter x: ";
	cin >> x;
	cout << "\nb) T(n) ";
	cout << "\nT(" << n << ") = " << t_n(n, x);
	
	cout << "\n\nEnter n: ";  //c)
	cin >> n;
	cout << "\nc) S(n) ";
	cout << "\nS(" << n << ") = " << s_n_2(n);
}
