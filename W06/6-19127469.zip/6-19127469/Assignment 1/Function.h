#ifndef FUNCTION_H
#define FUNCTION_H

#include<iostream>
using namespace std;

int s_n_1(int n);
int t_n(int n, int x);
float s_n_2(int n);

#endif
