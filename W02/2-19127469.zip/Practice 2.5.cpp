#include<iostream>
using namespace std;

struct Fraction
{
	int num, denom;
};

float Calc_Fraction(Fraction &a)
{
	return((float)a.num/a.denom);
}
void loadFractionArray(Fraction a[], int &n)
{
	cout << "How many fractions would you enter?:\n ";
	cin >> n;
	for(int i = 0; i < n; i++)
	{
		cout << "Enter your numerator["<<i<<"]:\n";
		cin >> a[i].num;
		cout << "Enter your denominator["<<i<<"]:\n";
		cin >> a[i].denom;
		cout<<"-------------------------------------------\n";
	}
}

int Negative_Fraction(Fraction a[], int &n, Fraction b[])
{
	int j = 0;
	for(int i = 0; i < n; i++)
	{
		if(Calc_Fraction(a[i]) < 0)
		{
			b[j] = a[i];
			j++;
		}
	}
	return j;
}

int main(void)
{
	
	Fraction a[100], b[100];
	int n;
	loadFractionArray(a, n);
	Fraction *p = b;
	int j = Negative_Fraction(a,n,b);
	for(int i = 0; i < j; i++)
	{
		cout << p->num << " " << p->denom << endl;
		p++;
	}
}
