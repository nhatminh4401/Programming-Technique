//main.cpp
#include "Function.h"

int main(void)
{
	int **a, *p, rows, cols;
	Input2DArray(a, rows, cols);
	cout << "==================================\n";
	int count = CountPrimes(a, rows, cols);
	GetPrimesList(a, rows, cols, p, count);
	cout << "Prime list:\n";
	PrintPrimesList(p, count);
	for(int i = 0; i < rows; i++)
	{
		delete[]a[i];
	}
	delete[]a;
	delete[]p;
}
