//Function.h
#ifndef _FUNCTION_H_
#define _FUNCTION_H_

#include<iostream>
using namespace std;
void Input2DArray(int **&a, int &rows, int &cols);
bool IsPrime(int &n);
int CountPrimes(int **a, int &rows, int &cols);
void GetPrimesList(int **a, int &rows, int &cols, int *&p, int &count);
void PrintPrimesList(int *p, int count);
#endif
