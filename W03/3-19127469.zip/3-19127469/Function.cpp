//Function.cpp
#include "Function.h"

void Input2DArray(int **&a, int &rows, int &cols)
{
	cout << "Enter number of rows and columns:\n";
	cin >> rows >> cols;
	cout << "==================================\n";
	a = new int*[rows];
	
	for(int i = 0; i < rows; i++)
	{
		a[i] = new int[cols];
		
		for(int j = 0; j < cols; j++)
		{
			cout << "a[" << i << "][" << j << "]: ";
			cin >> a[i][j];
		}	
	}
}

bool IsPrime(int &n)
{
	if(n == 1)
		return false;
	for(int i = 2; i <= n / 2; ++i)
   {
       if(n % i == 0)
       {
          return false;
       }
   }
   return true;
}

int CountPrimes(int **a, int &rows, int &cols)
{
	int count = 0;
	for(int i = 0; i < rows; i++)
	{
		for(int j = 0; j < cols; j++)
		{
			if(IsPrime(a[i][j]) == 1)
				count++;
		}	
	}
	return count;
}

void GetPrimesList(int **a, int &rows, int &cols, int *&p, int &count)
{
	p = new int[count];
	int count1 = count;
	for(int i = 0; i < rows; i++)
	{
		for(int j = 0; j < cols; j++)
		{
			if(IsPrime(a[i][j]) == 1)
			{
				
			    p[count-count1] = a[i][j]; //p[0],p[1],etc. = a[i][j]
			    count1--;
			}
		}	
	}
}

void PrintPrimesList(int *p, int count)
{
	for(int i = 0; i < count; i++)
		cout << *(p + i) << endl;
}


