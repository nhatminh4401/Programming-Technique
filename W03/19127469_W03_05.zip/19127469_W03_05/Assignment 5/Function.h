//Function.h
#ifndef _FUNCTION_H_
#define _FUNCTION_H_

#include<iostream>
using namespace std;

void inputArray(int *&a, int &n);
double median(int *a, int &n);

#endif
