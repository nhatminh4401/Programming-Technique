//Function.h
#ifndef _FUNCTION_H_
#define _FUNCTION_H_

#include<iostream>
using namespace std;

void inputArray(int *&a, int &n);
int Max_element(int *a, int &n);
int freq(int *a, int &n, int k);

#endif
